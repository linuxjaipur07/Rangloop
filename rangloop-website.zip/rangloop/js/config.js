// ⚠️  STEP 1: PASTE YOUR SUPABASE CREDENTIALS HERE
const SUPABASE_URL = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR_ANON_PUBLIC_KEY';

// ⚠️  STEP 2: PASTE YOUR RAZORPAY KEY HERE
// Get it from: razorpay.com → Settings → API Keys → Key ID
const RAZORPAY_KEY = 'rzp_test_YOUR_KEY_HERE'; // Replace with rzp_live_... for production

// ⚠️  STEP 3: EMAILJS CONFIG (free at emailjs.com)
// Setup: emailjs.com → Add Service (Gmail) → Add Template → Copy IDs
const EMAILJS_SERVICE_ID  = 'YOUR_SERVICE_ID';   // e.g. service_abc123
const EMAILJS_TEMPLATE_ID = 'YOUR_TEMPLATE_ID';  // e.g. template_xyz789
const EMAILJS_PUBLIC_KEY  = 'YOUR_PUBLIC_KEY';   // e.g. user_XXXXXXXXXX

// ⚠️  STEP 4: TWILIO CONFIG (free trial at twilio.com)
// For OTP SMS — needs a small backend (Netlify/Vercel function)
// OR use Fast2SMS (Indian service, easier): fast2sms.com
const FAST2SMS_API_KEY = 'YOUR_FAST2SMS_KEY';    // fast2sms.com → API → Dev API Key